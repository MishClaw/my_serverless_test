# my_serverless_test
testing a serverless demo https://github.com/serverless/examples/tree/master/aws-node-rest-api-with-dynamodb
